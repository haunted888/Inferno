using UnityEngine;

public class PartySlotController : MonoBehaviour
{
    public BattleSlots battleSlots;
    private BattleCharacter[] partyMembers;
    private Transform[] partyHomes;
    // Start is called once before the first execution of Update after the MonoBehaviour is created

    void Awake()
    {
        var defs = MapCombatTransfer.Instance.GetParty();

        foreach (var def in defs)
        {
            var inst = Instantiate(def.characterPrefab, this.transform);
            Debug.Log("Instantiated party member prefab: " + def.characterPrefab.name);
            var chr = inst.GetComponent<BattleCharacter>();
            if (chr == null) continue;

            chr.SetStats(def.health, def.speed);   
            chr.ClearSkills();
            foreach (var s in def.skills)
            {
                if (s != null)
                    chr.AddSkill(s);
            }
        }
    }

    void Start()
    {
        partyMembers = GetComponentsInChildren<BattleCharacter>();
        partyHomes = battleSlots.GetSlots(true, partyMembers, 1);
        GoToHome();
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    void GoToHome()
    {

        for (int i = 0; i < partyMembers.Length; i++)
        {
            partyMembers[i].transform.position = partyHomes[i].position;
        }
    }
}
