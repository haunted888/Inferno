using UnityEngine;
using System.Collections.Generic;

public class MapCombatTransfer : MonoBehaviour
{
    public static MapCombatTransfer Instance { get; private set; }

    private List<MapEnemyDefinition> pendingEnemies = new List<MapEnemyDefinition>();
    private List<MapPartyMemberDefinition> party = new List<MapPartyMemberDefinition>();

    void Awake()
    {
        if (Instance != null)
        {
            Destroy(gameObject);
            return;
        }
        Instance = this;
        DontDestroyOnLoad(gameObject);
    }

    public void SetupEnemies(MapEnemyDefinition[] defs)
    {
        pendingEnemies.Clear();
        if (defs != null)
            pendingEnemies.AddRange(defs);
    }

    public List<MapEnemyDefinition> GetEnemies()
    {
        var copy = new List<MapEnemyDefinition>(pendingEnemies);
        pendingEnemies.Clear();
        return copy;
    }

    public void SetupParty(MapPartyMemberDefinition[] defs)
    {
        party.Clear();
        if (defs != null)
            party.AddRange(defs);
    }
    public List<MapPartyMemberDefinition> GetParty()
    {
        return new List<MapPartyMemberDefinition>(party);
    }
}
