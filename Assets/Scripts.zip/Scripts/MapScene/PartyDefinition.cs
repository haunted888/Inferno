using UnityEngine;

public class PartyDefinition : MonoBehaviour
{
    public MapPartyMemberDefinition[] members;

    void Awake()
    {
        // Push current party into the transfer singleton
        MapCombatTransfer.Instance.SetupParty(members);
    }
}