using System.ComponentModel;
using UnityEngine;

[System.Serializable]
public class MapPartyMemberDefinition
{
    public GameObject characterPrefab;

    public string displayName = "Unnamed";

    [Header("Stats")]
    public int health = 100;
    public int speed  = 10;

    public Skill[] skills;
}
